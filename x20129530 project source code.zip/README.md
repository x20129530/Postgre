# TO run budgetapplication one needs to follow this steps
step-1: Install the django with this command "pip install django".
step-2: extract the zip file 
step 3: go to POSTGRE folder in cmd using this command "cd POSTGRE".
step 4: Run the server on your local machine with this command " python manage.py runserver"
step 5: open the url in your browser.

# to make migrations giving this commands
step-1: python manage.py makemigrations
step-2: python manage.py migrate

# each and every file is commented 
comments which starts with J are commented by me to give away details and rest all are default comments given bu Django Framework itself.

