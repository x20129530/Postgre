from django.apps import AppConfig


class BudgetappConfig(AppConfig):
    name = 'budgetapp'
